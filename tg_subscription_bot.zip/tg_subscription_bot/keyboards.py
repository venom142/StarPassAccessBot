"""Inline-клавиатуры."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import texts

CB_BUY = "buy"
CB_MY_SUB = "my_sub"
CB_JOIN = "get_link"


def main_menu(price: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=texts.buy_label(price), callback_data=CB_BUY)],
            [InlineKeyboardButton(text=texts.MY_SUB_LABEL, callback_data=CB_MY_SUB)],
        ]
    )


def renew(price: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=texts.renew_label(price), callback_data=CB_BUY)]]
    )


def subscription_menu(price: int, *, has_subscription: bool, show_join: bool) -> InlineKeyboardMarkup:
    label = texts.renew_label(price) if has_subscription else texts.buy_label(price)
    rows = [[InlineKeyboardButton(text=label, callback_data=CB_BUY)]]
    if show_join:
        rows.append([InlineKeyboardButton(text=texts.JOIN_LABEL, callback_data=CB_JOIN)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def join_channel(link: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=texts.JOIN_LABEL, url=link)]]
    )
