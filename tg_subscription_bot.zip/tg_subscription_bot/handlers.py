"""Обработчики Telegram: меню, оплата Stars, «Моя подписка»."""
from __future__ import annotations

import logging

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramAPIError
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    ErrorEvent,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)

import keyboards
import texts
from config import CURRENCY, Settings
from services import (
    LINK_ERROR,
    LINK_INACTIVE,
    SubscriptionService,
    invoice_payload,
)

log = logging.getLogger(__name__)

router = Router(name="subscription")
router.message.filter(F.chat.type == "private")


@router.message(CommandStart())
async def cmd_start(message: Message, settings: Settings) -> None:
    await message.answer(
        texts.welcome(settings.price_stars, settings.period_days),
        reply_markup=keyboards.main_menu(settings.price_stars),
    )


# --------------------------------------------------------------------- оплата
@router.callback_query(F.data == keyboards.CB_BUY)
async def cb_buy(callback: CallbackQuery, bot: Bot, settings: Settings) -> None:
    await callback.answer()
    user_id = callback.from_user.id
    try:
        await bot.send_invoice(
            chat_id=user_id,
            title=texts.invoice_title(),
            description=texts.invoice_description(settings.period_days),
            payload=invoice_payload(user_id),
            currency=CURRENCY,
            prices=[LabeledPrice(label=texts.invoice_label(settings.period_days), amount=settings.price_stars)],
        )
    except TelegramAPIError:
        log.exception("Не удалось создать счёт для %s", user_id)
        await bot.send_message(user_id, texts.invoice_failed())


@router.pre_checkout_query()
async def on_pre_checkout(query: PreCheckoutQuery, settings: Settings) -> None:
    """Telegram ждёт ответ не дольше 10 секунд — только быстрые проверки."""
    valid = (
        query.currency == CURRENCY
        and query.total_amount == settings.price_stars
        and query.invoice_payload == invoice_payload(query.from_user.id)
    )
    if valid:
        await query.answer(ok=True)
    else:
        log.warning(
            "pre_checkout отклонён: user=%s payload=%r amount=%s %s",
            query.from_user.id, query.invoice_payload, query.total_amount, query.currency,
        )
        await query.answer(ok=False, error_message=texts.invoice_invalid())


@router.message(F.successful_payment)
async def on_successful_payment(message: Message, service: SubscriptionService) -> None:
    payment = message.successful_payment
    user = message.from_user
    if payment is None or user is None:  # pragma: no cover
        return
    await service.process_successful_payment(
        user_id=user.id,
        username=user.username,
        charge_id=payment.telegram_payment_charge_id,
        provider_charge_id=payment.provider_payment_charge_id,
        amount=payment.total_amount,
        currency=payment.currency,
    )


# ------------------------------------------------------------ моя подписка
@router.callback_query(F.data == keyboards.CB_MY_SUB)
async def cb_my_subscription(
    callback: CallbackQuery, bot: Bot, service: SubscriptionService, settings: Settings
) -> None:
    await callback.answer()
    overview = await service.overview(callback.from_user.id)
    await bot.send_message(
        callback.from_user.id,
        texts.my_subscription(overview.sub, overview.now, settings.tz),
        reply_markup=keyboards.subscription_menu(
            settings.price_stars,
            has_subscription=overview.sub is not None,
            show_join=overview.can_request_link,
        ),
    )


@router.callback_query(F.data == keyboards.CB_JOIN)
async def cb_join(
    callback: CallbackQuery, bot: Bot, service: SubscriptionService, settings: Settings
) -> None:
    await callback.answer()
    user_id = callback.from_user.id
    result = await service.send_access_link(user_id)
    if result == LINK_INACTIVE:
        await bot.send_message(
            user_id,
            texts.expired_notice(settings.price_stars),
            reply_markup=keyboards.renew(settings.price_stars),
        )
    elif result == LINK_ERROR:
        await bot.send_message(user_id, texts.invoice_failed())


# ------------------------------------------------------------------ прочее
@router.message(F.text)
async def fallback(message: Message, settings: Settings) -> None:
    """Любой другой текст — показываем главное меню."""
    await message.answer(
        texts.welcome(settings.price_stars, settings.period_days),
        reply_markup=keyboards.main_menu(settings.price_stars),
    )


@router.errors()
async def on_error(event: ErrorEvent) -> bool:
    log.error("Необработанная ошибка в обработчике", exc_info=event.exception)
    return True
