"""Хранилище на SQLite. Все данные на диске, переживают перезапуск.

Используется стандартный sqlite3 в потоке (asyncio.to_thread) под общей
блокировкой, поэтому внешних зависимостей не нужно. Время хранится как
UNIX-время в секундах (UTC).
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterator

STATUS_ACTIVE = "active"
STATUS_EXPIRED = "expired"

SCHEMA = """
CREATE TABLE IF NOT EXISTS subscriptions (
    user_id        INTEGER PRIMARY KEY,
    username       TEXT,
    status         TEXT    NOT NULL CHECK (status IN ('active', 'expired')),
    paid_at        INTEGER NOT NULL,
    expires_at     INTEGER NOT NULL,
    last_charge_id TEXT,
    invite_link    TEXT,
    reminder_sent  INTEGER NOT NULL DEFAULT 0,
    link_pending   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payments (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    charge_id          TEXT    NOT NULL UNIQUE,
    provider_charge_id TEXT,
    user_id            INTEGER NOT NULL,
    username           TEXT,
    amount             INTEGER NOT NULL,
    currency           TEXT    NOT NULL,
    paid_at            INTEGER NOT NULL,
    expires_at         INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_payments_user ON payments (user_id);
CREATE INDEX IF NOT EXISTS idx_subs_status_expires ON subscriptions (status, expires_at);
"""


@dataclass(frozen=True)
class Subscription:
    user_id: int
    username: str | None
    status: str
    paid_at: int
    expires_at: int
    last_charge_id: str | None
    invite_link: str | None
    reminder_sent: bool
    link_pending: bool


@dataclass(frozen=True)
class PaymentResult:
    is_new: bool  # False — платёж с таким charge_id уже обрабатывался
    subscription: Subscription | None
    extended_active: bool  # продление при ещё действующей подписке


def _to_sub(row: sqlite3.Row | None) -> Subscription | None:
    if row is None:
        return None
    return Subscription(
        user_id=row["user_id"],
        username=row["username"],
        status=row["status"],
        paid_at=row["paid_at"],
        expires_at=row["expires_at"],
        last_charge_id=row["last_charge_id"],
        invite_link=row["invite_link"],
        reminder_sent=bool(row["reminder_sent"]),
        link_pending=bool(row["link_pending"]),
    )


class Database:
    def __init__(self, path: str) -> None:
        self._path = path
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ infra
    async def connect(self) -> None:
        await asyncio.to_thread(self._connect)

    def _connect(self) -> None:
        if self._path != ":memory:":
            Path(self._path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(
            self._path,
            check_same_thread=False,
            isolation_level=None,  # транзакциями управляем вручную
            timeout=30,
        )
        conn.row_factory = sqlite3.Row
        if self._path != ":memory:":
            conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        conn.executescript(SCHEMA)
        self._conn = conn

    async def close(self) -> None:
        def _close() -> None:
            with self._lock:
                if self._conn is not None:
                    self._conn.close()
                    self._conn = None

        await asyncio.to_thread(_close)

    async def _run(self, func: Callable[..., Any], *args: Any) -> Any:
        def runner() -> Any:
            with self._lock:
                assert self._conn is not None, "База данных не подключена"
                return func(self._conn, *args)

        return await asyncio.to_thread(runner)

    @staticmethod
    @contextmanager
    def _tx(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        else:
            conn.execute("COMMIT")

    # --------------------------------------------------------------- payments
    async def record_payment(
        self,
        *,
        user_id: int,
        username: str | None,
        charge_id: str,
        provider_charge_id: str | None,
        amount: int,
        currency: str,
        now: int,
        period_seconds: int,
    ) -> PaymentResult:
        """Атомарно сохраняет платёж и продлевает подписку.

        Повторная обработка того же charge_id ничего не меняет (идемпотентно).
        Если подписка ещё действует, новый срок отсчитывается от её окончания,
        иначе — от момента оплаты.
        """

        def op(conn: sqlite3.Connection) -> PaymentResult:
            with self._tx(conn):
                row = conn.execute(
                    "SELECT * FROM subscriptions WHERE user_id = ?", (user_id,)
                ).fetchone()
                if conn.execute(
                    "SELECT 1 FROM payments WHERE charge_id = ?", (charge_id,)
                ).fetchone():
                    return PaymentResult(False, _to_sub(row), False)

                active = (
                    row is not None
                    and row["status"] == STATUS_ACTIVE
                    and row["expires_at"] > now
                )
                base = row["expires_at"] if active else now
                expires_at = base + period_seconds

                conn.execute(
                    "INSERT INTO payments (charge_id, provider_charge_id, user_id, username,"
                    " amount, currency, paid_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (charge_id, provider_charge_id, user_id, username, amount, currency, now, expires_at),
                )
                conn.execute(
                    "INSERT INTO subscriptions (user_id, username, status, paid_at, expires_at,"
                    " last_charge_id, reminder_sent, link_pending)"
                    " VALUES (?, ?, 'active', ?, ?, ?, 0, 1)"
                    " ON CONFLICT(user_id) DO UPDATE SET"
                    "  username = excluded.username, status = 'active',"
                    "  paid_at = excluded.paid_at, expires_at = excluded.expires_at,"
                    "  last_charge_id = excluded.last_charge_id,"
                    "  reminder_sent = 0, link_pending = 1",
                    (user_id, username, now, expires_at, charge_id),
                )
                new_row = conn.execute(
                    "SELECT * FROM subscriptions WHERE user_id = ?", (user_id,)
                ).fetchone()
                return PaymentResult(True, _to_sub(new_row), active)

        return await self._run(op)

    # ---------------------------------------------------------------- queries
    async def get_subscription(self, user_id: int) -> Subscription | None:
        def op(conn: sqlite3.Connection) -> Subscription | None:
            return _to_sub(
                conn.execute("SELECT * FROM subscriptions WHERE user_id = ?", (user_id,)).fetchone()
            )

        return await self._run(op)

    async def due_for_reminder(self, now: int, window_seconds: int) -> list[Subscription]:
        def op(conn: sqlite3.Connection) -> list[Subscription]:
            rows = conn.execute(
                "SELECT * FROM subscriptions WHERE status = 'active' AND reminder_sent = 0"
                " AND expires_at > ? AND expires_at <= ? ORDER BY expires_at",
                (now, now + window_seconds),
            ).fetchall()
            return [_to_sub(r) for r in rows]  # type: ignore[misc]

        return await self._run(op)

    async def due_for_expiry(self, now: int) -> list[Subscription]:
        def op(conn: sqlite3.Connection) -> list[Subscription]:
            rows = conn.execute(
                "SELECT * FROM subscriptions WHERE status = 'active' AND expires_at <= ?"
                " ORDER BY expires_at",
                (now,),
            ).fetchall()
            return [_to_sub(r) for r in rows]  # type: ignore[misc]

        return await self._run(op)

    async def pending_link_users(self) -> list[int]:
        def op(conn: sqlite3.Connection) -> list[int]:
            rows = conn.execute(
                "SELECT user_id FROM subscriptions WHERE link_pending = 1 ORDER BY paid_at"
            ).fetchall()
            return [r["user_id"] for r in rows]

        return await self._run(op)

    # ---------------------------------------------------------------- updates
    async def mark_reminder_sent(self, user_id: int, expires_at: int) -> bool:
        def op(conn: sqlite3.Connection) -> bool:
            cur = conn.execute(
                "UPDATE subscriptions SET reminder_sent = 1 WHERE user_id = ? AND expires_at = ?",
                (user_id, expires_at),
            )
            return cur.rowcount > 0

        return await self._run(op)

    async def mark_expired(self, user_id: int, expires_at: int, now: int) -> bool:
        """Переводит в expired, только если подписку не продлили в промежутке."""

        def op(conn: sqlite3.Connection) -> bool:
            cur = conn.execute(
                "UPDATE subscriptions SET status = 'expired', link_pending = 0, invite_link = NULL"
                " WHERE user_id = ? AND status = 'active' AND expires_at = ? AND expires_at <= ?",
                (user_id, expires_at, now),
            )
            return cur.rowcount > 0

        return await self._run(op)

    async def set_link_pending(self, user_id: int, pending: bool) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "UPDATE subscriptions SET link_pending = ? WHERE user_id = ?",
                (1 if pending else 0, user_id),
            )

        await self._run(op)

    async def store_invite_link(self, user_id: int, link: str | None) -> None:
        def op(conn: sqlite3.Connection) -> None:
            conn.execute(
                "UPDATE subscriptions SET invite_link = ? WHERE user_id = ?", (link, user_id)
            )

        await self._run(op)

    async def count_payments(self, charge_id: str) -> int:
        def op(conn: sqlite3.Connection) -> int:
            return conn.execute(
                "SELECT COUNT(*) FROM payments WHERE charge_id = ?", (charge_id,)
            ).fetchone()[0]

        return await self._run(op)
