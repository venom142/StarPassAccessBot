"""Все тексты бота и форматирование дат."""
from __future__ import annotations

from datetime import datetime, tzinfo

from database import Subscription


def plural_days(n: int) -> str:
    n = abs(n)
    if n % 10 == 1 and n % 100 != 11:
        return f"{n} день"
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return f"{n} дня"
    return f"{n} дней"


def format_dt(ts: int, tz: tzinfo) -> str:
    return datetime.fromtimestamp(ts, tz).strftime("%d.%m.%Y %H:%M %Z").strip()


def format_remaining(seconds: int) -> str:
    seconds = max(0, int(seconds))
    total_minutes = -(-seconds // 60)  # округление вверх
    days, rest = divmod(total_minutes, 1440)
    hours, minutes = divmod(rest, 60)
    parts: list[str] = []
    if days:
        parts.append(f"{days} д.")
    if days or hours:
        parts.append(f"{hours} ч.")
    parts.append(f"{minutes} мин.")
    return " ".join(parts)


# ----------------------------------------------------------------- кнопки
def buy_label(price: int) -> str:
    return f"⭐ Купить доступ — {price} Stars"


def renew_label(price: int) -> str:
    return f"🔄 Продлить — {price} Stars"


MY_SUB_LABEL = "👤 Моя подписка"
JOIN_LABEL = "🔗 Вступить в канал"


# ---------------------------------------------------------------- сообщения
def welcome(price: int, period_days: int) -> str:
    return (
        "⭐ ДОБРО ПОЖАЛОВАТЬ!\n\n"
        "Для вступления в приватный канал необходимо приобрести подписку.\n\n"
        f"💰 Цена: {price} Stars\n"
        f"⏳ Срок: {plural_days(period_days)}"
    )


def invoice_title() -> str:
    return "Доступ в приватный канал"


def invoice_description(period_days: int) -> str:
    return (
        f"Подписка на {plural_days(period_days)}. "
        "Stars не списываются автоматически — каждое продление подтверждаете вы."
    )


def invoice_label(period_days: int) -> str:
    return f"Подписка на {plural_days(period_days)}"


def invoice_failed() -> str:
    return "⚠️ Не удалось создать счёт. Попробуйте ещё раз чуть позже."


def invoice_invalid() -> str:
    return "Счёт недействителен. Откройте /start и создайте новый."


def access_message(expires: str, link: str | None, just_paid: bool) -> str:
    if link:
        head = "✅ Оплата получена!" if just_paid else "✅ Подписка активна."
        return (
            f"{head}\n\n"
            f"Подписка действует до {expires}.\n\n"
            "🔗 Ваша персональная ссылка для вступления в канал "
            "(одноразовая, действует до окончания подписки):\n"
            f"{link}"
        )
    if just_paid:
        return (
            "✅ Оплата получена!\n\n"
            f"Подписка продлена и действует до {expires}.\n"
            "Вы уже состоите в канале — больше ничего делать не нужно."
        )
    return f"✅ Подписка действует до {expires}. Вы уже состоите в канале."


def payment_problem(charge_id: str) -> str:
    return (
        "⚠️ Платёж получен, но подписку активировать не удалось.\n"
        "Мы не потеряли его — сохраните номер платежа:\n"
        f"{charge_id}\n"
        "Попробуйте открыть «👤 Моя подписка» через несколько минут."
    )


def reminder(remaining: str, expires: str, price: int) -> str:
    return (
        "⏰ Подписка скоро закончится!\n\n"
        f"Осталось: {remaining}\n"
        f"Действует до: {expires}\n\n"
        f"Чтобы остаться в канале, продлите её за {price} Stars.\n"
        "Stars не списываются автоматически — вы подтверждаете каждую оплату сами."
    )


def expired_notice(price: int) -> str:
    return (
        "⌛ Срок подписки закончился, доступ к каналу закрыт.\n\n"
        f"Чтобы вернуться, оплатите новую подписку — {price} Stars."
    )


def my_subscription(sub: Subscription | None, now: int, tz: tzinfo) -> str:
    head = "👤 МОЯ ПОДПИСКА\n\n"
    if sub is None:
        return (
            head
            + "Статус: ❌ Нет подписки\n\n"
            "Дата оплаты: —\nДействует до: —\nОсталось: —"
        )
    active = sub.status == "active" and sub.expires_at > now
    status = "✅ Активна" if active else "❌ Истекла"
    remaining = format_remaining(sub.expires_at - now) if active else "—"
    return (
        head
        + f"Статус: {status}\n\n"
        f"Дата оплаты: {format_dt(sub.paid_at, tz)}\n"
        f"Действует до: {format_dt(sub.expires_at, tz)}\n"
        f"Осталось: {remaining}"
    )
