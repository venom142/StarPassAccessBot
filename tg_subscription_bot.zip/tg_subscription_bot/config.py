"""Настройки бота: константы подписки и чтение .env."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from datetime import timezone, tzinfo
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

log = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent

# Условия подписки
CURRENCY = "XTR"  # Telegram Stars
PRICE_STARS = 600
PERIOD_DAYS = 14
REMINDER_HOURS = 24  # за сколько часов до окончания напоминать
CHECK_INTERVAL_SECONDS = 30  # как часто фоновая задача проверяет БД


class ConfigError(RuntimeError):
    """Ошибка конфигурации (понятное сообщение для пользователя)."""


@dataclass(frozen=True)
class Settings:
    bot_token: str
    channel_id: int
    db_path: str = str(BASE_DIR / "data" / "bot.db")
    tz: tzinfo = timezone.utc
    price_stars: int = PRICE_STARS
    period_days: int = PERIOD_DAYS
    reminder_hours: int = REMINDER_HOURS
    check_interval: int = CHECK_INTERVAL_SECONDS

    @property
    def period_seconds(self) -> int:
        return self.period_days * 86400

    @property
    def reminder_seconds(self) -> int:
        return self.reminder_hours * 3600


def _load_dotenv(path: Path) -> None:
    """Минимальный разбор .env (KEY=VALUE), без внешних зависимостей."""
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)


def load_settings() -> Settings:
    _load_dotenv(BASE_DIR / ".env")

    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        raise ConfigError("Не задан BOT_TOKEN. Укажите токен от @BotFather в файле .env")

    raw_channel = os.environ.get("CHANNEL_ID", "").strip()
    if not raw_channel:
        raise ConfigError("Не задан CHANNEL_ID. Укажите числовой ID приватного канала (вида -100...)")
    try:
        channel_id = int(raw_channel)
    except ValueError:
        raise ConfigError(f"CHANNEL_ID должен быть числом вида -1001234567890, получено: {raw_channel!r}")

    db_path = os.environ.get("DB_PATH", "").strip()
    if not db_path:
        db_path = str(BASE_DIR / "data" / "bot.db")
    elif not Path(db_path).is_absolute():
        db_path = str(BASE_DIR / db_path)

    tz_name = os.environ.get("TIMEZONE", "Europe/Kyiv").strip() or "Europe/Kyiv"
    try:
        tz: tzinfo = ZoneInfo(tz_name)
    except (ZoneInfoNotFoundError, ValueError):
        log.warning("Часовой пояс %r не найден (установите пакет tzdata), используется UTC", tz_name)
        tz = timezone.utc

    return Settings(bot_token=token, channel_id=channel_id, db_path=db_path, tz=tz)
