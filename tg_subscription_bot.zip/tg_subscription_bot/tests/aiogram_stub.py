"""Минимальная заглушка aiogram для запуска тестов без установленной библиотеки.

Если настоящий aiogram установлен, заглушка не включается и тесты идут
с реальными классами исключений и типов.
"""
from __future__ import annotations

import sys
import types


def install() -> bool:
    try:
        import aiogram  # noqa: F401

        return False
    except ImportError:
        pass

    root = types.ModuleType("aiogram")
    root.__path__ = []  # type: ignore[attr-defined]

    # ---- exceptions
    exc = types.ModuleType("aiogram.exceptions")

    class TelegramAPIError(Exception):
        def __init__(self, method, message):
            super().__init__(message)
            self.method = method
            self.message = message

    class TelegramNetworkError(TelegramAPIError): ...

    class TelegramServerError(TelegramAPIError): ...

    class TelegramBadRequest(TelegramAPIError): ...

    class TelegramForbiddenError(TelegramAPIError): ...

    class TelegramRetryAfter(TelegramAPIError):
        def __init__(self, method, message, retry_after):
            super().__init__(method, message)
            self.retry_after = retry_after

    for cls in (
        TelegramAPIError, TelegramNetworkError, TelegramServerError,
        TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter,
    ):
        setattr(exc, cls.__name__, cls)

    # ---- types
    tp = types.ModuleType("aiogram.types")

    class _Simple:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    for name in (
        "InlineKeyboardButton", "InlineKeyboardMarkup", "LabeledPrice",
        "CallbackQuery", "Message", "PreCheckoutQuery", "ErrorEvent",
    ):
        setattr(tp, name, type(name, (_Simple,), {}))

    # ---- filters
    flt = types.ModuleType("aiogram.filters")
    flt.CommandStart = lambda *a, **k: object()  # type: ignore[attr-defined]

    # ---- root: Bot, Router, F, Dispatcher
    class _F:
        def __getattr__(self, item):
            return _F()

        def __eq__(self, other):  # type: ignore[override]
            return _F()

        def __hash__(self):
            return id(self)

    class _Observer:
        def filter(self, *a, **k):
            return None

        def __call__(self, *a, **k):
            return lambda fn: fn

    class Router:
        def __init__(self, name=None):
            self.message = _Observer()
            self.callback_query = _Observer()
            self.pre_checkout_query = _Observer()
            self.errors = _Observer()

    root.Bot = type("Bot", (), {})  # type: ignore[attr-defined]
    root.Dispatcher = type("Dispatcher", (), {})  # type: ignore[attr-defined]
    root.Router = Router  # type: ignore[attr-defined]
    root.F = _F()  # type: ignore[attr-defined]

    sys.modules["aiogram"] = root
    sys.modules["aiogram.exceptions"] = exc
    sys.modules["aiogram.types"] = tp
    sys.modules["aiogram.filters"] = flt
    return True
