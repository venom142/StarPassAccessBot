"""Сценарные тесты: python -m unittest discover -s tests -v"""
from __future__ import annotations

import asyncio
import os
import sqlite3
import sys
import tempfile
import unittest
from datetime import timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import aiogram_stub  # noqa: E402

aiogram_stub.install()

from aiogram.exceptions import (  # noqa: E402
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
)

import handlers  # noqa: E402
import texts  # noqa: E402
from config import Settings  # noqa: E402
from database import Database  # noqa: E402
from services import (  # noqa: E402
    LINK_INACTIVE,
    LINK_SENT,
    PAYMENT_DUPLICATE,
    PAYMENT_FAILED,
    PAYMENT_GRANTED,
    PAYMENT_REJECTED,
    SubscriptionService,
)

T0 = 1_800_000_000
DAY = 86400
PERIOD = 14 * DAY


class Clock:
    def __init__(self, t: int = T0) -> None:
        self.t = t

    def __call__(self) -> float:
        return self.t


class FakeBot:
    def __init__(self) -> None:
        self.sent: list[tuple[int, str, object]] = []
        self.links: list[dict] = []
        self.revoked: list[str] = []
        self.banned: list[int] = []
        self.unbanned: list[int] = []
        self.members: dict[int, str] = {}
        self.invoices: list[dict] = []
        self.fail_next: dict[str, list[Exception]] = {}
        self.fail_always: dict[str, Exception] = {}

    def _maybe_fail(self, name: str) -> None:
        queue = self.fail_next.get(name)
        if queue:
            raise queue.pop(0)
        if name in self.fail_always:
            raise self.fail_always[name]

    async def send_message(self, chat_id, text, reply_markup=None, **kw):
        self._maybe_fail("send_message")
        self.sent.append((chat_id, text, reply_markup))

    async def send_invoice(self, **kw):
        self._maybe_fail("send_invoice")
        self.invoices.append(kw)

    async def get_chat_member(self, chat_id, user_id):
        self._maybe_fail("get_chat_member")
        status = self.members.get(user_id, "left")
        return SimpleNamespace(status=status, is_member=status == "member")

    async def create_chat_invite_link(self, chat_id, name=None, expire_date=None, member_limit=None):
        self._maybe_fail("create_chat_invite_link")
        link = f"https://t.me/+link{len(self.links) + 1}"
        self.links.append({"link": link, "name": name, "expire_date": expire_date, "member_limit": member_limit})
        return SimpleNamespace(invite_link=link)

    async def revoke_chat_invite_link(self, chat_id, invite_link):
        self._maybe_fail("revoke_chat_invite_link")
        self.revoked.append(invite_link)

    async def ban_chat_member(self, chat_id, user_id, **kw):
        self._maybe_fail("ban_chat_member")
        self.banned.append(user_id)
        self.members[user_id] = "kicked"

    async def unban_chat_member(self, chat_id, user_id, only_if_banned=None):
        self._maybe_fail("unban_chat_member")
        self.unbanned.append(user_id)
        if self.members.get(user_id) == "kicked":
            self.members[user_id] = "left"

    def texts_to(self, user_id: int) -> list[str]:
        return [t for uid, t, _ in self.sent if uid == user_id]


def make_settings(db_path: str = ":memory:") -> Settings:
    return Settings(bot_token="t", channel_id=-1001, db_path=db_path, tz=timezone.utc)


def button_texts(markup) -> list[str]:
    return [b.text for row in markup.inline_keyboard for b in row]


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self._sleep = patch("asyncio.sleep", new=AsyncMock())
        self._sleep.start()
        self.clock = Clock()
        self.bot = FakeBot()
        self.settings = make_settings()
        self.db = Database(":memory:")
        await self.db.connect()
        self.service = SubscriptionService(self.bot, self.db, self.settings, clock=self.clock)

    async def asyncTearDown(self) -> None:
        await self.db.close()
        self._sleep.stop()

    async def pay(self, user=1, charge="c1", amount=600, currency="XTR", username="alice"):
        return await self.service.process_successful_payment(
            user_id=user, username=username, charge_id=charge,
            provider_charge_id="p" + charge, amount=amount, currency=currency,
        )


class PaymentTests(Base):
    async def test_first_payment_grants_access(self):
        self.assertEqual(await self.pay(), PAYMENT_GRANTED)
        sub = await self.db.get_subscription(1)
        self.assertEqual(sub.status, "active")
        self.assertEqual(sub.paid_at, T0)
        self.assertEqual(sub.expires_at, T0 + PERIOD)
        self.assertEqual(sub.username, "alice")
        self.assertEqual(sub.last_charge_id, "c1")
        self.assertFalse(sub.link_pending)
        self.assertEqual(len(self.bot.links), 1)
        self.assertEqual(self.bot.links[0]["member_limit"], 1)
        self.assertEqual(self.bot.links[0]["expire_date"], T0 + PERIOD)
        messages = self.bot.texts_to(1)
        self.assertEqual(len(messages), 1)
        self.assertIn(self.bot.links[0]["link"], messages[0])

    async def test_duplicate_charge_is_ignored(self):
        await self.pay()
        self.assertEqual(await self.pay(), PAYMENT_DUPLICATE)
        sub = await self.db.get_subscription(1)
        self.assertEqual(sub.expires_at, T0 + PERIOD)
        self.assertEqual(len(self.bot.links), 1)
        self.assertEqual(len(self.bot.texts_to(1)), 1)
        self.assertEqual(await self.db.count_payments("c1"), 1)

    async def test_concurrent_duplicates_grant_once(self):
        results = await asyncio.gather(self.pay(), self.pay(), self.pay())
        self.assertEqual(sorted(results), [PAYMENT_DUPLICATE, PAYMENT_DUPLICATE, PAYMENT_GRANTED])
        self.assertEqual((await self.db.get_subscription(1)).expires_at, T0 + PERIOD)
        self.assertEqual(len(self.bot.links), 1)

    async def test_wrong_amount_or_currency_rejected(self):
        self.assertEqual(await self.pay(amount=100), PAYMENT_REJECTED)
        self.assertEqual(await self.pay(charge="c2", currency="USD"), PAYMENT_REJECTED)
        self.assertIsNone(await self.db.get_subscription(1))
        self.assertEqual(self.bot.links, [])

    async def test_early_renewal_extends_from_expiry_without_new_link(self):
        await self.pay()
        self.bot.members[1] = "member"
        self.clock.t = T0 + 10 * DAY
        await self.pay(charge="c2")
        sub = await self.db.get_subscription(1)
        self.assertEqual(sub.expires_at, T0 + 2 * PERIOD)
        self.assertEqual(sub.paid_at, T0 + 10 * DAY)
        self.assertFalse(sub.reminder_sent)
        self.assertEqual(len(self.bot.links), 1)
        self.assertIn("продлена", self.bot.texts_to(1)[-1])

    async def test_payment_after_expiry_starts_from_payment_time_and_new_link(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 100
        await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "expired")
        await self.pay(charge="c2")
        sub = await self.db.get_subscription(1)
        self.assertEqual(sub.status, "active")
        self.assertEqual(sub.expires_at, T0 + PERIOD + 100 + PERIOD)
        self.assertEqual(len(self.bot.links), 2)
        self.assertIn(self.bot.links[1]["link"], self.bot.texts_to(1)[-1])

    async def test_db_error_is_retried(self):
        real = self.db.record_payment
        calls = {"n": 0}

        async def flaky(**kw):
            calls["n"] += 1
            if calls["n"] < 3:
                raise sqlite3.OperationalError("database is locked")
            return await real(**kw)

        self.db.record_payment = flaky  # type: ignore[method-assign]
        self.assertEqual(await self.pay(), PAYMENT_GRANTED)
        self.assertEqual(calls["n"], 3)
        self.assertEqual((await self.db.get_subscription(1)).status, "active")

    async def test_db_permanently_down_tells_user_charge_id(self):
        async def broken(**kw):
            raise sqlite3.OperationalError("disk I/O error")

        self.db.record_payment = broken  # type: ignore[method-assign]
        with self.assertLogs("services", level="CRITICAL"):
            self.assertEqual(await self.pay(), PAYMENT_FAILED)
        self.assertIn("c1", self.bot.texts_to(1)[-1])


class DeliveryTests(Base):
    async def test_link_creation_failure_is_retried_by_scheduler(self):
        self.bot.fail_next["create_chat_invite_link"] = [TelegramBadRequest(None, "Bad Request: chat not found")]
        with self.assertLogs("services", level="ERROR"):
            self.assertEqual(await self.pay(), PAYMENT_GRANTED)
        self.assertTrue((await self.db.get_subscription(1)).link_pending)
        self.assertEqual(self.bot.texts_to(1), [])
        await self.service.run_once()
        self.assertFalse((await self.db.get_subscription(1)).link_pending)
        self.assertEqual(len(self.bot.texts_to(1)), 1)
        self.assertEqual(len(self.bot.links), 1)

    async def test_blocked_bot_revokes_link_and_stops_retrying(self):
        self.bot.fail_always["send_message"] = TelegramForbiddenError(None, "Forbidden: bot was blocked by the user")
        with self.assertLogs("services", level="WARNING"):
            self.assertEqual(await self.pay(), PAYMENT_GRANTED)
        sub = await self.db.get_subscription(1)
        self.assertFalse(sub.link_pending)
        self.assertEqual(sub.status, "active")
        self.assertEqual(self.bot.revoked, [self.bot.links[0]["link"]])

    async def test_flood_limit_is_waited_out(self):
        self.bot.fail_next["send_message"] = [TelegramRetryAfter(None, "Too Many Requests", retry_after=3)]
        self.assertEqual(await self.pay(), PAYMENT_GRANTED)
        self.assertEqual(len(self.bot.texts_to(1)), 1)
        self.assertFalse((await self.db.get_subscription(1)).link_pending)

    async def test_manual_link_request(self):
        await self.pay()
        self.bot.sent.clear()
        self.assertEqual(await self.service.send_access_link(1), LINK_SENT)
        self.assertEqual(len(self.bot.links), 2)
        self.assertEqual(self.bot.revoked, [self.bot.links[0]["link"]])
        self.assertIn("Подписка активна", self.bot.texts_to(1)[-1])
        self.assertNotIn("Оплата получена", self.bot.texts_to(1)[-1])

    async def test_manual_link_request_for_member_creates_no_link(self):
        await self.pay()
        self.bot.members[1] = "member"
        self.assertEqual(await self.service.send_access_link(1), LINK_SENT)
        self.assertEqual(len(self.bot.links), 1)
        self.assertIn("уже состоите", self.bot.texts_to(1)[-1])

    async def test_manual_link_request_without_subscription(self):
        self.assertEqual(await self.service.send_access_link(1), LINK_INACTIVE)
        await self.pay()
        self.clock.t = T0 + PERIOD + 1
        self.assertEqual(await self.service.send_access_link(1), LINK_INACTIVE)

    async def test_overview_link_button_logic(self):
        await self.pay()
        self.assertTrue((await self.service.overview(1)).can_request_link)
        self.bot.members[1] = "member"
        self.assertFalse((await self.service.overview(1)).can_request_link)
        self.assertFalse((await self.service.overview(99)).is_active)


class ReminderTests(Base):
    def reminders(self):
        return [t for t in self.bot.texts_to(1) if "скоро закончится" in t]

    async def test_reminder_sent_once_within_last_24h(self):
        await self.pay()
        self.clock.t = T0 + PERIOD - 25 * 3600
        await self.service.run_once()
        self.assertEqual(self.reminders(), [])
        self.clock.t = T0 + PERIOD - 23 * 3600
        await self.service.run_once()
        await self.service.run_once()
        self.assertEqual(len(self.reminders()), 1)
        self.assertIn("600 Stars", self.reminders()[0])
        markup = [m for uid, t, m in self.bot.sent if "скоро закончится" in t][0]
        self.assertEqual(button_texts(markup), ["🔄 Продлить — 600 Stars"])

    async def test_renewal_rearms_reminder(self):
        await self.pay()
        self.clock.t = T0 + PERIOD - 3600
        await self.service.run_once()
        await self.pay(charge="c2")
        self.assertFalse((await self.db.get_subscription(1)).reminder_sent)
        self.clock.t = T0 + 2 * PERIOD - 3600
        await self.service.run_once()
        self.assertEqual(len(self.reminders()), 2)

    async def test_reminder_failure_is_retried_and_block_is_final(self):
        await self.pay()
        self.clock.t = T0 + PERIOD - 3600
        self.bot.fail_next["send_message"] = [TelegramBadRequest(None, "Bad Request: oops")]
        with self.assertLogs("services", level="WARNING"):
            await self.service.run_once()
        self.assertFalse((await self.db.get_subscription(1)).reminder_sent)
        await self.service.run_once()
        self.assertEqual(len(self.reminders()), 1)

        await self.pay(user=2, charge="c2", username=None)
        self.bot.fail_always["send_message"] = TelegramForbiddenError(None, "Forbidden: bot was blocked by the user")
        # второй оплатил в T0+PERIOD-3600, его подписка кончается в T0+2*PERIOD-3600
        self.clock.t = T0 + 2 * PERIOD - 7200
        await self.service.send_reminders()
        self.assertTrue((await self.db.get_subscription(2)).reminder_sent)


class ExpiryTests(Base):
    async def test_expired_user_is_kicked_notified_and_link_revoked(self):
        await self.pay()
        self.bot.members[1] = "member"
        self.clock.t = T0 + PERIOD - 1
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [])
        self.clock.t = T0 + PERIOD
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [1])
        self.assertEqual(self.bot.members[1], "left")  # исключён, но не забанен навсегда
        self.assertEqual(self.bot.revoked, [self.bot.links[0]["link"]])
        sub = await self.db.get_subscription(1)
        self.assertEqual(sub.status, "expired")
        self.assertIsNone(sub.invite_link)
        last = [(t, m) for uid, t, m in self.bot.sent if uid == 1][-1]
        self.assertIn("доступ к каналу закрыт", last[0])
        self.assertEqual(button_texts(last[1]), ["🔄 Продлить — 600 Stars"])
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [1])  # повторно не исключаем

    async def test_late_payment_before_job_keeps_user(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 5
        await self.pay(charge="c2")
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [])
        self.assertEqual((await self.db.get_subscription(1)).status, "active")

    async def test_recheck_under_lock_skips_renewed_subscription(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 5
        stale = await self.db.due_for_expiry(self.clock.t)
        self.assertEqual(len(stale), 1)
        await self.pay(charge="c2")
        await self.service._expire_one(1)
        self.assertEqual(self.bot.banned, [])

    async def test_transient_kick_failure_keeps_subscription_until_success(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 1
        self.bot.fail_next["ban_chat_member"] = [TelegramNetworkError(None, "net")] * 3
        with self.assertLogs("services", level="ERROR"):
            await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "active")
        await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "expired")

    async def test_missing_admin_rights_keep_retrying(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 1
        self.bot.fail_always["ban_chat_member"] = TelegramBadRequest(
            None, "Bad Request: not enough rights to restrict/unrestrict chat member"
        )
        with self.assertLogs("services", level="ERROR"):
            await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "active")
        del self.bot.fail_always["ban_chat_member"]
        await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "expired")

    async def test_owner_cannot_be_kicked_subscription_closes(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 1
        self.bot.fail_always["ban_chat_member"] = TelegramBadRequest(
            None, "Bad Request: can't remove chat owner"
        )
        with self.assertLogs("services", level="WARNING"):
            await self.service.run_once()
        self.assertEqual((await self.db.get_subscription(1)).status, "expired")

    async def test_blocked_user_still_removed(self):
        await self.pay()
        self.clock.t = T0 + PERIOD + 1
        self.bot.fail_always["send_message"] = TelegramForbiddenError(None, "Forbidden: bot was blocked by the user")
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [1])
        self.assertEqual((await self.db.get_subscription(1)).status, "expired")

    async def test_other_users_not_affected(self):
        await self.pay(user=1)
        self.clock.t = T0 + 5 * DAY
        await self.pay(user=2, charge="c2", username="bob")
        self.clock.t = T0 + PERIOD + 1
        await self.service.run_once()
        self.assertEqual(self.bot.banned, [1])
        self.assertEqual((await self.db.get_subscription(2)).status, "active")


class PersistenceTests(unittest.IsolatedAsyncioTestCase):
    async def test_state_and_tasks_survive_restart(self):
        with patch("asyncio.sleep", new=AsyncMock()), tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "sub", "bot.db")
            clock = Clock()
            bot = FakeBot()
            db1 = Database(path)
            await db1.connect()
            service = SubscriptionService(bot, db1, make_settings(path), clock=clock)
            await service.process_successful_payment(
                user_id=7, username="u", charge_id="x1", provider_charge_id=None, amount=600, currency="XTR"
            )
            await db1.close()

            # «перезапуск»: новое подключение к тому же файлу
            clock.t = T0 + PERIOD + 50
            db2 = Database(path)
            await db2.connect()
            sub = await db2.get_subscription(7)
            self.assertEqual((sub.status, sub.expires_at, sub.last_charge_id), ("active", T0 + PERIOD, "x1"))
            service2 = SubscriptionService(bot, db2, make_settings(path), clock=clock)
            await service2.run_once()
            self.assertEqual(bot.banned, [7])
            self.assertEqual((await db2.get_subscription(7)).status, "expired")
            # платёж, обработанный до перезапуска, не применится повторно
            result = await service2.process_successful_payment(
                user_id=7, username="u", charge_id="x1", provider_charge_id=None, amount=600, currency="XTR"
            )
            self.assertEqual(result, PAYMENT_DUPLICATE)
            self.assertEqual((await db2.get_subscription(7)).status, "expired")
            await db2.close()


class TextTests(unittest.TestCase):
    def test_plural_days(self):
        self.assertEqual(
            [texts.plural_days(n) for n in (1, 2, 5, 11, 14, 21, 22)],
            ["1 день", "2 дня", "5 дней", "11 дней", "14 дней", "21 день", "22 дня"],
        )

    def test_format_remaining(self):
        self.assertEqual(texts.format_remaining(14 * DAY), "14 д. 0 ч. 0 мин.")
        self.assertEqual(texts.format_remaining(13 * DAY + 23 * 3600 + 59 * 60 + 1), "14 д. 0 ч. 0 мин.")
        self.assertEqual(texts.format_remaining(3600 + 60), "1 ч. 1 мин.")
        self.assertEqual(texts.format_remaining(10), "1 мин.")
        self.assertEqual(texts.format_remaining(-5), "0 мин.")

    def test_welcome_text(self):
        self.assertEqual(
            texts.welcome(600, 14),
            "⭐ ДОБРО ПОЖАЛОВАТЬ!\n\n"
            "Для вступления в приватный канал необходимо приобрести подписку.\n\n"
            "💰 Цена: 600 Stars\n⏳ Срок: 14 дней",
        )


class HandlerTests(Base):
    """Хендлеры вызываются напрямую с поддельными объектами Telegram."""

    def user_message(self):
        return SimpleNamespace(answer=AsyncMock())

    async def test_start_menu(self):
        msg = self.user_message()
        await handlers.cmd_start(msg, self.settings)
        text = msg.answer.call_args.args[0]
        self.assertTrue(text.startswith("⭐ ДОБРО ПОЖАЛОВАТЬ!"))
        self.assertEqual(
            button_texts(msg.answer.call_args.kwargs["reply_markup"]),
            ["⭐ Купить доступ — 600 Stars", "👤 Моя подписка"],
        )

    async def test_buy_creates_stars_invoice(self):
        cb = SimpleNamespace(answer=AsyncMock(), from_user=SimpleNamespace(id=7))
        await handlers.cb_buy(cb, self.bot, self.settings)
        inv = self.bot.invoices[0]
        self.assertEqual(inv["chat_id"], 7)
        self.assertEqual(inv["currency"], "XTR")
        self.assertEqual(inv["payload"], "sub:7")
        self.assertEqual(inv["prices"][0].amount, 600)
        self.assertNotIn("provider_token", inv)

    async def test_buy_failure_informs_user(self):
        self.bot.fail_always["send_invoice"] = TelegramBadRequest(None, "Bad Request: x")
        cb = SimpleNamespace(answer=AsyncMock(), from_user=SimpleNamespace(id=7))
        with self.assertLogs("handlers", level="ERROR"):
            await handlers.cb_buy(cb, self.bot, self.settings)
        self.assertIn("Не удалось создать счёт", self.bot.texts_to(7)[-1])

    def pre_checkout(self, **over):
        data = dict(
            from_user=SimpleNamespace(id=5), currency="XTR", total_amount=600,
            invoice_payload="sub:5", answer=AsyncMock(),
        )
        data.update(over)
        return SimpleNamespace(**data)

    async def test_pre_checkout_validation(self):
        ok = self.pre_checkout()
        await handlers.on_pre_checkout(ok, self.settings)
        ok.answer.assert_awaited_once_with(ok=True)
        for bad in (
            self.pre_checkout(total_amount=1),
            self.pre_checkout(currency="USD"),
            self.pre_checkout(invoice_payload="sub:6"),
            self.pre_checkout(invoice_payload="junk"),
        ):
            with self.assertLogs("handlers", level="WARNING"):
                await handlers.on_pre_checkout(bad, self.settings)
            self.assertFalse(bad.answer.call_args.kwargs["ok"])
            self.assertTrue(bad.answer.call_args.kwargs["error_message"])

    def payment_message(self, charge="h1"):
        return SimpleNamespace(
            from_user=SimpleNamespace(id=5, username="carol"),
            successful_payment=SimpleNamespace(
                telegram_payment_charge_id=charge, provider_payment_charge_id="",
                total_amount=600, currency="XTR", invoice_payload="sub:5",
            ),
        )

    async def test_successful_payment_handler_is_idempotent(self):
        await handlers.on_successful_payment(self.payment_message(), self.service)
        await handlers.on_successful_payment(self.payment_message(), self.service)
        sub = await self.db.get_subscription(5)
        self.assertEqual((sub.username, sub.expires_at), ("carol", T0 + PERIOD))
        self.assertEqual(len(self.bot.links), 1)

    async def my_sub(self, user_id=5):
        cb = SimpleNamespace(answer=AsyncMock(), from_user=SimpleNamespace(id=user_id))
        await handlers.cb_my_subscription(cb, self.bot, self.service, self.settings)
        _, text, markup = self.bot.sent[-1]
        return text, button_texts(markup)

    async def test_my_subscription_views(self):
        text, buttons = await self.my_sub()
        self.assertIn("Нет подписки", text)
        self.assertEqual(buttons, ["⭐ Купить доступ — 600 Stars"])

        await self.pay(user=5)
        text, buttons = await self.my_sub()
        self.assertIn("✅ Активна", text)
        self.assertIn("Осталось: 14 д. 0 ч. 0 мин.", text)
        self.assertIn("Дата оплаты: ", text)
        self.assertIn("Действует до: ", text)
        self.assertEqual(buttons, ["🔄 Продлить — 600 Stars", "🔗 Вступить в канал"])

        self.bot.members[5] = "member"
        _, buttons = await self.my_sub()
        self.assertEqual(buttons, ["🔄 Продлить — 600 Stars"])

        self.clock.t = T0 + PERIOD + 10
        text, buttons = await self.my_sub()
        self.assertIn("❌ Истекла", text)
        self.assertIn("Осталось: —", text)
        self.assertEqual(buttons, ["🔄 Продлить — 600 Stars"])

    async def test_join_button_for_expired_user_offers_renewal(self):
        cb = SimpleNamespace(answer=AsyncMock(), from_user=SimpleNamespace(id=5))
        await handlers.cb_join(cb, self.bot, self.service, self.settings)
        self.assertIn("доступ к каналу закрыт", self.bot.texts_to(5)[-1])


if __name__ == "__main__":
    unittest.main()
