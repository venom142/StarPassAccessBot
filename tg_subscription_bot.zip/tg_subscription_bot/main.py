"""Точка входа: python main.py"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.exceptions import TelegramAPIError

from config import ConfigError, Settings, load_settings
from database import Database
from handlers import router
from services import SubscriptionService

log = logging.getLogger("bot")


async def verify_channel_access(bot: Bot, settings: Settings) -> None:
    """Проверяет при старте, что бот видит канал и имеет нужные права администратора."""
    me = await bot.get_me()
    try:
        chat = await bot.get_chat(settings.channel_id)
        member = await bot.get_chat_member(chat.id, me.id)
    except TelegramAPIError as exc:
        raise SystemExit(
            f"Бот не имеет доступа к каналу {settings.channel_id}: {exc}\n"
            "Проверьте CHANNEL_ID и добавьте бота в канал администратором."
        )

    status = str(getattr(member.status, "value", member.status))
    if status == "creator":
        return
    if status != "administrator":
        raise SystemExit("Бот должен быть администратором канала (права: приглашение и блокировка участников).")
    missing = [
        name
        for attr, name in (
            ("can_invite_users", "«Приглашение пользователей через ссылку»"),
            ("can_restrict_members", "«Блокировка пользователей»"),
        )
        if not getattr(member, attr, False)
    ]
    if missing:
        raise SystemExit("Выдайте боту в канале права администратора: " + ", ".join(missing))


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        stream=sys.stdout,
    )
    try:
        settings = load_settings()
    except ConfigError as exc:
        raise SystemExit(str(exc))

    db = Database(settings.db_path)
    await db.connect()
    bot = Bot(token=settings.bot_token)
    scheduler: asyncio.Task | None = None
    try:
        await verify_channel_access(bot, settings)

        service = SubscriptionService(bot, db, settings)
        dp = Dispatcher()
        dp["service"] = service
        dp["settings"] = settings
        dp.include_router(router)

        # Для long polling вебхук должен быть снят. Накопившиеся апдейты НЕ сбрасываем:
        # среди них могут быть уведомления об оплате.
        await bot.delete_webhook(drop_pending_updates=False)

        scheduler = asyncio.create_task(service.run_forever(), name="subscription-scheduler")
        log.info("Бот запущен")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        if scheduler is not None:
            scheduler.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await scheduler
        await bot.session.close()
        await db.close()
        log.info("Бот остановлен")


if __name__ == "__main__":
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(main())
