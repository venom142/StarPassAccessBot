"""Бизнес-логика: выдача доступа, напоминания, исключение, фоновый цикл.

Всё состояние хранится в БД, поэтому после перезапуска фоновая задача просто
продолжает с того места, где остановилась: просроченные подписки будут
обработаны, недоставленные ссылки — отправлены повторно.
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
import time
import weakref
from dataclasses import dataclass
from typing import TYPE_CHECKING, Awaitable, Callable, TypeVar

from aiogram.exceptions import (
    TelegramAPIError,
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNetworkError,
    TelegramRetryAfter,
    TelegramServerError,
)

import keyboards
import texts
from config import CURRENCY, Settings
from database import STATUS_ACTIVE, Database, Subscription

if TYPE_CHECKING:  # pragma: no cover
    from aiogram import Bot

log = logging.getLogger(__name__)
T = TypeVar("T")

PAYMENT_GRANTED = "granted"
PAYMENT_DUPLICATE = "duplicate"
PAYMENT_REJECTED = "rejected"
PAYMENT_FAILED = "failed"

LINK_SENT = "sent"
LINK_INACTIVE = "inactive"
LINK_ERROR = "error"

# Ошибки Telegram при исключении, которые повторять бессмысленно.
_PERMANENT_KICK_ERRORS = (
    "can't remove chat owner",
    "user is an administrator",
    "participant_id_invalid",
    "user_not_participant",
    "user not found",
)


def invoice_payload(user_id: int) -> str:
    return f"sub:{user_id}"


@dataclass(frozen=True)
class Overview:
    sub: Subscription | None
    now: int
    is_active: bool
    can_request_link: bool


def _status_value(member: object) -> str:
    status = getattr(member, "status", "")
    return str(getattr(status, "value", status))


class SubscriptionService:
    def __init__(
        self,
        bot: "Bot",
        db: Database,
        settings: Settings,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.bot = bot
        self.db = db
        self.settings = settings
        self._clock = clock
        self._locks: "weakref.WeakValueDictionary[int, asyncio.Lock]" = weakref.WeakValueDictionary()

    # --------------------------------------------------------------- helpers
    def _now(self) -> int:
        return int(self._clock())

    def _lock(self, user_id: int) -> asyncio.Lock:
        lock = self._locks.get(user_id)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[user_id] = lock
        return lock

    async def _tg(self, factory: Callable[[], Awaitable[T]], attempts: int = 3) -> T:
        """Вызов Telegram API с повтором при флуд-лимите и сетевых сбоях."""
        for attempt in range(1, attempts + 1):
            try:
                return await factory()
            except TelegramRetryAfter as exc:
                if attempt == attempts:
                    raise
                await asyncio.sleep(exc.retry_after + 1)
            except (TelegramNetworkError, TelegramServerError):
                if attempt == attempts:
                    raise
                await asyncio.sleep(2 ** (attempt - 1))
        raise RuntimeError("unreachable")  # pragma: no cover

    async def _send(self, user_id: int, text: str, markup: object | None = None) -> bool:
        """Отправка пользователю. False — если не вышло (бот заблокирован и т.п.)."""
        try:
            await self._tg(lambda: self.bot.send_message(user_id, text, reply_markup=markup))
            return True
        except TelegramForbiddenError:
            log.info("Пользователь %s недоступен для сообщений (бот заблокирован)", user_id)
        except TelegramAPIError as exc:
            log.warning("Не удалось отправить сообщение %s: %s", user_id, exc)
        return False

    async def _is_member(self, user_id: int) -> bool | None:
        """True/False — состоит ли пользователь в канале; None — не удалось узнать."""
        try:
            member = await self._tg(
                lambda: self.bot.get_chat_member(self.settings.channel_id, user_id)
            )
        except TelegramBadRequest as exc:
            log.info("get_chat_member(%s): %s — считаем, что в канале нет", user_id, exc)
            return False
        except TelegramAPIError as exc:
            log.warning("get_chat_member(%s) не удался: %s", user_id, exc)
            return None
        status = _status_value(member)
        if status in ("creator", "administrator", "member"):
            return True
        if status == "restricted":
            return bool(getattr(member, "is_member", False))
        return False

    async def _revoke_quietly(self, link: str | None) -> None:
        if not link:
            return
        try:
            await self._tg(
                lambda: self.bot.revoke_chat_invite_link(self.settings.channel_id, link)
            )
        except TelegramAPIError as exc:
            log.debug("Не удалось отозвать ссылку: %s", exc)

    async def _unban_quietly(self, user_id: int) -> None:
        try:
            await self._tg(
                lambda: self.bot.unban_chat_member(
                    self.settings.channel_id, user_id, only_if_banned=True
                )
            )
        except TelegramAPIError as exc:
            log.debug("unban_chat_member(%s): %s", user_id, exc)

    # ------------------------------------------------------------- платежи
    async def process_successful_payment(
        self,
        *,
        user_id: int,
        username: str | None,
        charge_id: str,
        provider_charge_id: str | None,
        amount: int,
        currency: str,
    ) -> str:
        """Обрабатывает successful_payment. Безопасно вызывать повторно."""
        if currency != CURRENCY or amount != self.settings.price_stars:
            log.critical(
                "Платёж с неверной суммой/валютой не активирован: user=%s charge=%s %s %s",
                user_id, charge_id, amount, currency,
            )
            await self._send(user_id, texts.payment_problem(charge_id))
            return PAYMENT_REJECTED

        async with self._lock(user_id):
            result = None
            for attempt in range(1, 6):
                try:
                    result = await self.db.record_payment(
                        user_id=user_id,
                        username=username,
                        charge_id=charge_id,
                        provider_charge_id=provider_charge_id,
                        amount=amount,
                        currency=currency,
                        now=self._now(),
                        period_seconds=self.settings.period_seconds,
                    )
                    break
                except sqlite3.Error:
                    log.exception("Ошибка записи платежа %s (попытка %s/5)", charge_id, attempt)
                    await asyncio.sleep(min(2 ** (attempt - 1), 8))

            if result is None:
                log.critical(
                    "ПЛАТЁЖ НЕ ЗАПИСАН В БД: user=%s username=%s charge=%s provider_charge=%s %s %s",
                    user_id, username, charge_id, provider_charge_id, amount, currency,
                )
                await self._send(user_id, texts.payment_problem(charge_id))
                return PAYMENT_FAILED

            if not result.is_new:
                log.info("Повторная доставка платежа %s проигнорирована", charge_id)
                return PAYMENT_DUPLICATE

            log.info(
                "Платёж %s от %s принят, подписка до %s",
                charge_id, user_id, result.subscription.expires_at if result.subscription else "?",
            )
            await self._deliver_locked(user_id, just_paid=True)
            return PAYMENT_GRANTED

    # ------------------------------------------------------- выдача доступа
    async def _deliver_locked(self, user_id: int, *, just_paid: bool, force: bool = False) -> bool:
        """Создаёт одноразовую ссылку и отправляет её. Никогда не бросает исключений.

        Возвращает True, если доставка завершена (или делать нечего),
        False — если нужно повторить позже.
        """
        link: str | None = None
        try:
            sub = await self.db.get_subscription(user_id)
            if sub is None:
                return True
            if not force and not sub.link_pending:
                return True
            now = self._now()
            if sub.status != STATUS_ACTIVE or sub.expires_at <= now:
                await self.db.set_link_pending(user_id, False)
                return True

            member = await self._is_member(user_id)
            if member is not True:
                await self._unban_quietly(user_id)
                await self._revoke_quietly(sub.invite_link)
                invite = await self._tg(
                    lambda: self.bot.create_chat_invite_link(
                        chat_id=self.settings.channel_id,
                        name=f"sub {user_id}",
                        expire_date=sub.expires_at,
                        member_limit=1,
                    )
                )
                link = invite.invite_link
                await self.db.store_invite_link(user_id, link)

            expires = texts.format_dt(sub.expires_at, self.settings.tz)
            await self._tg(
                lambda: self.bot.send_message(
                    user_id,
                    texts.access_message(expires, link, just_paid),
                    reply_markup=keyboards.join_channel(link) if link else None,
                )
            )
            await self.db.set_link_pending(user_id, False)
            return True
        except TelegramForbiddenError:
            # Пользователь заблокировал бота: доставить нечего, ссылку отзываем.
            log.warning("Не удалось доставить доступ %s: бот заблокирован пользователем", user_id)
            await self._revoke_quietly(link)
            try:
                await self.db.store_invite_link(user_id, None)
                await self.db.set_link_pending(user_id, False)
            except sqlite3.Error:
                log.exception("Не удалось сбросить флаг доставки для %s", user_id)
            return False
        except Exception:
            log.exception("Не удалось выдать доступ пользователю %s, повторим позже", user_id)
            return False

    async def retry_pending_links(self) -> None:
        for user_id in await self.db.pending_link_users():
            async with self._lock(user_id):
                await self._deliver_locked(user_id, just_paid=True)

    async def send_access_link(self, user_id: int) -> str:
        """Ручной запрос ссылки активным подписчиком (кнопка «Вступить в канал»)."""
        async with self._lock(user_id):
            sub = await self.db.get_subscription(user_id)
            if sub is None or sub.status != STATUS_ACTIVE or sub.expires_at <= self._now():
                return LINK_INACTIVE
            ok = await self._deliver_locked(user_id, just_paid=False, force=True)
            return LINK_SENT if ok else LINK_ERROR

    async def overview(self, user_id: int) -> Overview:
        sub = await self.db.get_subscription(user_id)
        now = self._now()
        active = sub is not None and sub.status == STATUS_ACTIVE and sub.expires_at > now
        can_link = False
        if active:
            can_link = await self._is_member(user_id) is not True
        return Overview(sub=sub, now=now, is_active=active, can_request_link=can_link)

    # ----------------------------------------------------------- напоминания
    async def send_reminders(self) -> None:
        window = self.settings.reminder_seconds
        for candidate in await self.db.due_for_reminder(self._now(), window):
            try:
                await self._remind_one(candidate.user_id, window)
            except Exception:
                log.exception("Ошибка напоминания пользователю %s", candidate.user_id)

    async def _remind_one(self, user_id: int, window: int) -> None:
        async with self._lock(user_id):
            now = self._now()
            sub = await self.db.get_subscription(user_id)
            if (
                sub is None
                or sub.status != STATUS_ACTIVE
                or sub.reminder_sent
                or not (now < sub.expires_at <= now + window)
            ):
                return
            text = texts.reminder(
                texts.format_remaining(sub.expires_at - now),
                texts.format_dt(sub.expires_at, self.settings.tz),
                self.settings.price_stars,
            )
            try:
                await self._tg(
                    lambda: self.bot.send_message(
                        user_id, text, reply_markup=keyboards.renew(self.settings.price_stars)
                    )
                )
            except TelegramForbiddenError:
                log.info("Напоминание %s не доставлено: бот заблокирован", user_id)
            except TelegramAPIError as exc:
                log.warning("Напоминание %s не отправлено (повторим): %s", user_id, exc)
                return
            await self.db.mark_reminder_sent(user_id, sub.expires_at)

    # ------------------------------------------------------------ исключение
    async def expire_due(self) -> None:
        for candidate in await self.db.due_for_expiry(self._now()):
            try:
                await self._expire_one(candidate.user_id)
            except Exception:
                log.exception("Ошибка при завершении подписки %s", candidate.user_id)

    async def _expire_one(self, user_id: int) -> None:
        async with self._lock(user_id):
            now = self._now()
            sub = await self.db.get_subscription(user_id)
            # Перепроверка под блокировкой: вдруг подписку только что продлили.
            if sub is None or sub.status != STATUS_ACTIVE or sub.expires_at > now:
                return
            if not await self._remove_from_channel(user_id):
                return
            await self._revoke_quietly(sub.invite_link)
            if await self.db.mark_expired(user_id, sub.expires_at, now):
                log.info("Подписка %s закончилась, пользователь исключён", user_id)
                await self._send(
                    user_id,
                    texts.expired_notice(self.settings.price_stars),
                    keyboards.renew(self.settings.price_stars),
                )

    async def _remove_from_channel(self, user_id: int) -> bool:
        """Исключает из канала без постоянного бана. True — можно закрывать подписку."""
        chat_id = self.settings.channel_id
        try:
            await self._tg(lambda: self.bot.ban_chat_member(chat_id, user_id))
            await self._tg(
                lambda: self.bot.unban_chat_member(chat_id, user_id, only_if_banned=True)
            )
            return True
        except TelegramBadRequest as exc:
            if any(marker in str(exc).lower() for marker in _PERMANENT_KICK_ERRORS):
                log.warning("Исключение %s невозможно (%s), подписка закрывается", user_id, exc)
                return True
            log.error("Не удалось исключить %s, повторим: %s", user_id, exc)
        except TelegramAPIError as exc:
            log.error("Не удалось исключить %s, повторим: %s", user_id, exc)
        return False

    # ---------------------------------------------------------- фоновый цикл
    async def run_once(self) -> None:
        for step in (self.retry_pending_links, self.send_reminders, self.expire_due):
            try:
                await step()
            except Exception:
                log.exception("Сбой шага фоновой проверки %s", step.__name__)

    async def run_forever(self) -> None:
        log.info("Фоновая проверка подписок запущена (каждые %s с)", self.settings.check_interval)
        while True:
            await self.run_once()
            await asyncio.sleep(self.settings.check_interval)
